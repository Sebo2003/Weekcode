def example_function(n):
    # Operation with O(n/2)
    for i in range(n//2):
        print(f"Operation - Iteration {i}")

# Example usage
example_function(10)

#o(n)